# Handoff: FinOps Cloud-Native — Consola de costes AWS

## Overview
Dashboard FinOps para equipos con gasto AWS de ~$500k/mes. Responde tres preguntas: cuánto ya ahorramos, cuánto queda por capturar y qué gasto se está desviando. Cuatro pantallas: **Dashboard · Anomalías · Oportunidades · Realizados**. Idioma de la UI: español.

## About the Design Files
Los archivos de este paquete son **referencias de diseño hechas en HTML** — prototipos que muestran aspecto y comportamiento, no código de producción. La tarea es **recrearlos en el entorno del codebase destino** (React, Vue, etc.) con sus patrones y librerías. Si no hay codebase, se recomienda **React + TypeScript + Vite**, CSS Modules o Tailwind (con los tokens de abajo como CSS variables), **Recharts/visx** o SVG propio para gráficos, y **@phosphor-icons/react** para iconos.

`FinOps Console v8.dc.html` abre directamente en el navegador (necesita `support.js`, `assets/` y `_ds/` a su lado). Toda la lógica y los datos mock están en el bloque `<script data-dc-script>` al final del archivo (clase `Component`, método `renderVals()`).

## Fidelity
**High-fidelity.** Colores, tipografía, radios, espaciados e interacciones son finales. Recrear pixel-perfect.

---

## Layout global (App shell)
- Root: `display:flex; height:100vh; overflow:hidden`, fondo `--bg`.
- **Sidebar** (`<aside>`): ancho 252px (abierto) / 76px (colapsado), transición `width .2s ease`. `padding:20px 14px`, `border-right:1px solid --line`, columna con `gap:6px`.
  - Marca: tile 40×40, radio 12, fondo `#ffffff`, logo `assets/logo-n.png` a 26px de ancho. Junto: "FinOps Cloud-Native" (17px/500, letter-spacing -0.01em, nowrap). Oculto el texto al colapsar.
  - Nav (4 items): botón alto 46px, `padding:0 14px`, radio 12, gap 12, icono 20px + label 14.5px. Activo: fondo `--card2`, texto `--t`, barra indicadora 3px a la izquierda (`--acc`, top/bottom 12px, radio `0 3px 3px 0`). Inactivo: transparente, `--t2`. Hover: fondo `--card2`, texto `--t`.
    - Dashboard `ph-squares-four` · Anomalías `ph-warning-diamond` (badge "3": 11.5px, padding 2×8, radio 20, fondo `--bad-t`, texto `--bad`) · Oportunidades `ph-lightbulb` · Realizados `ph-check-circle`.
  - Spacer flex:1.
  - Estado de sincronización (solo abierto): card padding 14, radio 16, fondo `--card`, borde `--line`. Punto 7px `--ok` con animación `pulseDot 2s infinite` (opacidad 1→0.25→1) + texto 12.5px `--t1`: "Actualizado hace 5 min" / "Actualizado justo ahora".
  - Botón colapsar: alto 42, radio 12, `ph-caret-left` 16px (rota 180° al colapsar, `.2s`), label "Colapsar".
- **Main**: `flex:1; overflow:auto`.
  - **Header** sticky top, z 5, fondo `--bg`, `padding:22px 40px`, `border-bottom:1px solid --line`, flex wrap gap 16.
    - Izquierda: título 24px/500 (ls -0.02em) + subtítulo 13.5px `--t2`.
    - Derecha (grupo `flex:none; margin-left:auto; gap:10px`, todo nowrap):
      1. Pill fecha: alto 40, padding 0 14, radio 12, borde `--line2`, 13.5px `--t1`, icono `ph-calendar-blank` 17px, "Agosto 2026 · MTD".
      2. **Botón Sincronizar**: alto 40, padding 0 16, radio 12, borde 1px `--acc`, fondo transparente, texto `--acc-soft` 13.5px/500, icono `ph-arrows-clockwise` 17px. Hover/active fondo `--acc-t`. Ver comportamiento abajo.
      3. Toggle tema: 40×40, radio 12, borde `--line2`, icono `ph-sun` (en oscuro) / `ph-moon` (en claro).
  - **Contenido**: `padding:32px 40px 64px`, columna gap 20, `max-width:1480px`. Cada pantalla entra con animación `rise` (.4s: opacity 0, translateY 10px → none).

### Card base
Fondo `--card`, borde `1px solid --line`, radio 24 (cards grandes de héroe: 28), padding `28px 32px`. Cabecera de card: título 18px/500 + subtítulo 14px `--t2`, gap 4. Enlace "Ver todas/Ver todos ↗": 14px `--acc`, hover `--acc-soft`, icono `ph-arrow-up-right`.

### Fila de lista (patrón usado en las 4 pantallas)
Fila clicable (role=button, tabindex 0, Enter/Espacio abre), `padding:16px; margin:0 -16px; radio 16`, hover fondo `--card2` (`.15s`). Tile icono 42×42 radio 12 con fondo tint + icono 19px. Texto principal 14.5px, secundario 13px `--t2`, terciario 12.5px `--t3`, todos con ellipsis. Importe a la derecha en `--num` 14.5–15px. Chevron `ph-caret-right` `--t3` al final en las pantallas de detalle.

### Control segmentado (filtros)
Contenedor padding 4, radio 12, fondo `--card2`, gap 4. Opción: padding 7×14, radio 9, 13px. Activa: fondo `--card`, texto `--t`; inactiva transparente, `--t2`.

---

## Screens

### 1. Dashboard
Subtítulo: "Qué ya ahorramos, qué queda por capturar y qué se está desviando".

**Fila 1 (bento)** — grid `repeat(auto-fit, minmax(min(100%,440px),1fr))`, gap 20.
- **Héroe "Ya ahorrados"** (clic → Realizados): radio 28, fondo `--hero-bg`, texto `--hero-t`, padding `44px 48px`, min-height 360, `--shadow`. Trama decorativa arriba-derecha (72%×78%): `repeating-linear-gradient(135deg, --hero-hatch 0 1px, transparent 1px 15px)` con `mask-image: radial-gradient(ellipse at top right, #000 10%, transparent 70%)`.
  - Pill "YA AHORRADOS · AGOSTO": padding 8×16, radio 30, fondo `--hero-pill`, 12.5px/500, ls 0.12em, uppercase, `--hero-t2`.
  - Valor "$78,900": `clamp(64px,7vw,96px)`, peso 300, ls -0.045em, lh 0.95. Debajo 15px `--hero-t2`: "$946.8k anualizado · 14 tickets cerrados".
  - Pie: párrafo 16px/1.5 máx 400px "Medido en el CUR tras el cierre de cada ticket FINOPS. Un 21% por encima del objetivo mensual de $65k." + "Ver realizados ↗" 14px/500.
- **Columna derecha** (grid 2 filas, gap 20):
  - Card "Ahorro identificado" (clic → Oportunidades): radio 28, padding `36px 40px`. Kicker 12.5px/500 ls 0.14em uppercase `--t2`; valor "$63,480" 52px/300 ls -0.035em; sub 14px "18 recomendaciones abiertas · $761.8k/año". Derecha: 12 barras de 8px ancho, radio 6, color `--bar-on`, alturas `[8,12,18,14,24,22,30,28,38,42,48,56]px`, opacidad lineal 0.35→1.
  - Sub-grid `minmax(150px,0.7fr) minmax(0,1.6fr)`:
    - "3 / ANOMALÍAS" centrado (fondo `--card2`, radio 28): 44px/300 + label uppercase. Clic → Anomalías.
    - Card impacto: círculo 60px fondo `--bad-t` icono `ph-fill ph-warning` 26px `--bad`; "$10,120 / día" 22px + "2 críticas sobre la banda esperada" 14px `--t2`. Clic → Anomalías.

**Fila 2** — flex wrap gap 20.
- **Gráfico "Ahorro mensual realizado"** (`flex:2 1 560px`): sub "Medido en CUR frente al objetivo · 2026". Leyenda: punto 9px `--acc` "Realizado", guion discontinuo `--t3` "Objetivo". Eje Y a la izquierda (40px, 12px `--t3`): $90k/$60k/$30k/$0. Área 240px alto:
  - Datos (k$): Realizado `[21,28,34,39,46,58,68,79]`, Objetivo `[30,35,40,45,50,55,60,65]`, meses Ene–Ago. Escala 0–90k.
  - Línea realizado: curva suave (Catmull-Rom → Bézier), 2.5px `--acc`; área con gradiente vertical `--acc` 0.32 → 0. Objetivo: 2px `--t3` dash `6 6`. Grid horizontal punteado `3 5` `--line`; base `--line2`.
  - Hover por columna: línea vertical `--line2`, punto 12px (borde 2.5px `--acc`, fondo `--bg`), tooltip (fondo `--card2`, borde `--line2`, radio 12, padding 10×14) con "Mes 2026", valor ("$79,000") y diferencia vs objetivo en `--ok` ("+$14k vs objetivo"). Por defecto resaltado el último mes; al salir vuelve al último.
- **"Oportunidades por fuente"** (`flex:1 1 320px`): sub "Ahorro mensual identificado". Barras 8px radio 8 sobre `--card2`, ancho relativo al máximo:
  - Cost Optimization Hub · 11 recs · $29,340 · `--acc`
  - Compute Optimizer · 7 recs · $22,160 · `--acc-soft`
  - Trusted Advisor · 4 checks · $8,940 · `--acc-deep`
  - Reglas propias · 2 reglas · $3,040 · `--t3`
  - Pie con borde superior: "Total identificado" / "$63,480" (26px).

**Fila 3** — dos cards `flex:1 1 440px`:
- "Anomalías recientes" (sub "Cost Anomaly Detection · últimos 7 días", "Ver todas ↗"): 4 primeras anomalías; derecha "+$5,840/día" en color de severidad + severidad 12.5px `--t3`.
- "Últimos realizados" (sub "Tickets FINOPS cerrados en agosto", "Ver todos ↗"): 4 primeros tickets; tile `ph-check` tint `--ok-t`; "FINOPS-396 · 19 Ago 2026"; importe `--ok`.

### 2. Anomalías
Subtítulo: "Gasto fuera de la banda esperada, por impacto diario".
- **4 stat cards tintadas** (grid `minmax(min(100%,240px),1fr)`): radio 24, padding 32, min-height 200, fondo/borde tint; icono 34px arriba, valor 48px/400 ls -0.03em, label 16px `--t1`.
  - Anomalías activas · 3 · `ph-warning-octagon` · bad
  - Impacto diario · $10.1k · `ph-trend-up` · warn
  - Acumulado del mes · $96.4k · `ph-stack` · acc
  - Tiempo medio de detección · 4.2 h · `ph-timer` · ok
- **"Detecciones"** (`flex:3 1 620px`, sub "Desvío sobre la banda esperada de 60 días") con segmentado **Todas / Crítica / Media / Baja**. Fila en grid `42px minmax(0,2.4fr) minmax(90px,1fr) minmax(90px,auto) 18px`: icono · recurso + pill severidad + hallazgo + "servicio · cuenta · región · hace X" · desvío "+412%" con barra 6px (ancho = min(desvío/4.5, 100)%) · "+$5,840/día" y "$35,040 acumulado".
- **"Por servicio"** (`flex:1 1 280px`, sub "Detecciones en 90 días"): EKS 4 (bad), EC2 3, S3 2, RDS 2 (warn), Lambda 1 (`--t3`); barra = count/4.

Severidad → estilo: Crítica = `--bad`/`--bad-t`/`ph-fill ph-warning-octagon`; Media = `--warn`/`--warn-t`/`ph-warning`; Baja = `--t2`/`--card2`/`ph-info`.

### 3. Oportunidades
Subtítulo: "Cost Optimization Hub, Compute Optimizer y reglas propias".
- **4 KPI cards** (grid `minmax(min(100%,280px),1fr)`, radio 22, padding 26×28): label 14.5px `--t1`, valor 34px/400; arriba-derecha 7 mini barras 4px (última `--bar-on`, resto `--bar-dim`); delta 13px con `ph-trend-up/down`; separador `--line`; nota con `ph-sparkle` 14px/1.5.
  - Ahorro identificado · $63,480 · +$7.2k vs julio (ok) · "65% del total es de riesgo bajo y no requiere ventana de cambio."
  - Cost Optimization Hub · $29,340 · +$3.1k vs julio · "Intelligent-Tiering en el datalake concentra el 20% del hub."
  - Compute Optimizer · $22,160 · −$1.4k vs julio (warn) · "Baja tras migrar los runners de CI a Spot; quedan 7 rightsizings."
  - Aceptadas este mes · 79% · +6 pp vs julio · "Tiempo medio de apertura a cierre en Jira: 11 días."
- **"Recomendaciones abiertas"** (sub "Ordenadas por ahorro mensual · al aceptar se crea un ticket FINOPS") con segmentado **Todas / Opt. Hub / Compute Opt. / Trusted Advisor / Propias**. Grid `42px minmax(0,2.2fr) minmax(120px,1fr) 80px minmax(100px,auto) 18px`: icono por fuente (Hub `ph-gauge`, CO `ph-cpu`, TA `ph-shield-check`, Propias `ph-sliders-horizontal`; tile `--acc-t`/`--acc-soft`) · recomendación + recurso en JetBrains Mono 13px · fuente · pill riesgo (Bajo ok / Medio warn) · ahorro `--ok`.

### 4. Realizados
Subtítulo: "Ahorro de tickets FINOPS cerrados, medido en el CUR".
- **Héroe "Acumulado 2026"** (mismo estilo héroe, padding 40×44): "$412,600" `clamp(56px,6vw,84px)`/300; "68 tickets FINOPS cerrados desde enero"; 8 barras mensuales (máx 34px ancho, radio 8, color `--hero-t`, altura = v/79, opacidad 0.28 salvo la última 1) con meses Ene–Ago. Valores k$: `[21,28,34,39,46,58,68,79]`.
- **4 stat cards tintadas** (grid `minmax(200px,1fr)`, radio 24, padding 28×30, min-height 150, valor 40px):
  - Realizado en agosto · $78.9k · `ph-calendar-check` · ok
  - Tasa de ejecución · 79% · `ph-target` · acc
  - Tiempo medio de cierre · 11 d · `ph-hourglass-medium` · warn
  - Desvío vs estimación · −7% · `ph-scales` · neutro (`--card`/`--line`)
- **"Tickets cerrados · agosto"** (sub "Ahorro medido en CUR, 30 días antes y después del cierre"): grid `42px minmax(0,2.2fr) minmax(130px,1fr) 110px minmax(100px,auto) 18px`: check · acción + "FINOPS-xxx · recurso" (mono) · fuente · fecha · ahorro `--ok`. **Sin columna de verificación** — el estado (Verificado / En observación) solo aparece en el modal.

---

## Modal de detalle (compartido)
Backdrop fijo `rgba(6,6,9,0.62)` + `backdrop-filter: blur(6px)`, clic fuera cierra. Panel `min(640px,100%)`, max-height 88vh scroll, radio 28, fondo `--card`, borde `--line2`, padding 36×40, gap 24, animación `rise .25s`.
- Kicker pill (12px/500 uppercase ls 0.1em, fondo `--card2`), título 24px/500, sub 14px `--t2`. Botón cerrar 38×38 `ph-x`.
- 3 stats en grid (fondo `--card2`, radio 18, padding 18; label 12.5px, valor 20px `--num` con color).
- Párrafo 15px/1.6 `--t1`.
- Lista con título 13px `--t2`; filas separadas por `--line`: nombre 14.5px, meta 12.5px `--t3`, valor 13.5px.
- Acciones: "Cerrar" (ghost) + acción principal (outline `--acc`, texto `--acc-soft`, hover `--acc-t`).

Contenido por origen:
- **Anomalía**: kicker "Cost Anomaly Detection"; stats Severidad / Impacto diario / Acumulado; cuerpo = hallazgo + "Desvío del N% sobre la banda esperada de los últimos 60 días…"; lista "Acciones sugeridas" (Revertir cambio = 72% del impacto/día, Abrir ticket de seguimiento, Regla de detección específica). Acción **"Abrir ticket en Jira"** → crea ticket.
- **Oportunidad**: kicker = fuente; stats Ahorro mensual / Anualizado (×12) / Riesgo; lista "Plan de ejecución" (Abrir ticket en Jira, Ventana sábado 02:00–04:00 UTC, Verificación 30 días en CUR). Acción **"Crear ticket en Jira"** → crea ticket.
- **Realizado**: kicker "Jira · FINOPS-xxx"; stats Ahorro medido / Anualizado / Estado (Verificado ok, En observación warn); lista "Trazabilidad" (ticket, Estimación al abrir = ahorro×1.08, Ahorro medido en CUR). Acción "Abrir en Jira" (cierra; en producción enlazar a la URL de Jira).

## Interactions & Behavior
- **Navegación**: 4 pantallas en el sidebar; las cards del dashboard llevan a su pantalla (héroe → Realizados, Identificado → Oportunidades, anomalías → Anomalías).
- **Sincronizar**: al pulsar → `syncing=true`, botón deshabilitado, texto "Sincronizando…", icono gira (`spin 0.9s linear infinite`). Al terminar → `syncing=false`, sidebar muestra "Actualizado justo ahora", toast "Datos sincronizados". En el prototipo es un timeout de 1.6s; en producción debe disparar el refetch de todas las fuentes (ver Data). Si falla: mostrar toast de error y mantener la marca de tiempo anterior.
- **Crear ticket**: cierra el modal y muestra toast "Ticket FINOPS-413 creado en Jira" (número incremental). En producción: POST a la API de Jira (proyecto FINOPS), owner desde el tag `Team` del recurso.
- **Toast**: fijo abajo-centro (bottom 28), fondo `--hero-bg`, texto `--hero-t`, radio 16, padding 14×20, icono `ph-fill ph-check-circle`, desaparece a los 2.8s.
- **Tema**: toggle oscuro/claro; cambia todo el set de tokens.
- **Sidebar**: colapsar/expandir.
- **Teclado**: toda fila/card clicable es focusable y responde a Enter/Espacio. Focus ring `2px solid --acc`, offset 2px.
- **Responsive**: grids `auto-fit/minmax` y flex-wrap; header agrupa los controles de la derecha y baja completo bajo el título en anchos estrechos.

## State Management
```
screen: 'dashboard' | 'alerts' | 'optimize' | 'done'
theme: 'dark' | 'light'
sidebarOpen: boolean
modal: null | { kicker, title, sub, stats[3], body, listTitle, list[], action, onAction? }
chartHoverIndex: number           // por defecto último mes
anomalySeverityFilter: 'all' | 'Crítica' | 'Media' | 'Baja'
opportunitySourceFilter: 'all' | 'Cost Optimization Hub' | 'Compute Optimizer' | 'Trusted Advisor' | 'Reglas propias'
syncing: boolean; lastSyncedAt: Date
toast: string | null
```

## Data (fuentes sugeridas para producción)
- **Ya ahorrados / Realizados**: tickets FINOPS en estado Done (Jira API) + ahorro medido en AWS CUR (Athena) comparando 30 días antes/después del cierre.
- **Ahorro identificado / Oportunidades**: AWS Cost Optimization Hub (`ListRecommendations`), Compute Optimizer, Trusted Advisor (categoría cost), reglas propias.
- **Anomalías**: AWS Cost Anomaly Detection (`GetAnomalies`), impacto diario y acumulado.
- Todos los datos del prototipo son **mock** (en `renderVals()` y los métodos `anomalies()`, `opportunities()`, `done()`). Formato moneda: `$` + `toLocaleString('en-US')`.

## Design Tokens
Tipografía: **Inter** 300/400/500 (UI); números en `--num` = Inter (variante opcional JetBrains Mono); IDs de recursos en **JetBrains Mono**. Peso máximo 500. `-webkit-font-smoothing: antialiased`.

| Token | Oscuro | Claro |
|---|---|---|
| --bg | #0c0d10 | #f1f1f3 |
| --card | #141519 | #ffffff |
| --card2 | #1b1c21 | #f6f6f8 |
| --line | rgba(236,236,239,.07) | rgba(19,20,24,.07) |
| --line2 | rgba(236,236,239,.13) | rgba(19,20,24,.13) |
| --t | #ececef | #16171b |
| --t1 | rgba(236,236,239,.74) | rgba(22,23,27,.76) |
| --t2 | rgba(236,236,239,.54) | rgba(22,23,27,.56) |
| --t3 | rgba(236,236,239,.34) | rgba(22,23,27,.38) |
| --acc | #9184d9 | #6455c0 |
| --acc-soft | #b5abfc | #54479f |
| --acc-deep | #5f54a3 | #9a90dd |
| --acc-t | rgba(145,132,217,.13) | rgba(100,85,192,.10) |
| --ok / --ok-t | #7fd4a8 / rgba(127,212,168,.13) | #1f8a5f / rgba(31,138,95,.11) |
| --warn / --warn-t | #e0b878 / rgba(224,184,120,.14) | #8a5a13 / rgba(138,90,19,.11) |
| --bad / --bad-t | #e58e8e / rgba(229,142,142,.14) | #b04141 / rgba(176,65,65,.10) |
| --ok-bg / --ok-b | #0e1b15 / rgba(127,212,168,.18) | #ecf6f1 / rgba(31,138,95,.16) |
| --warn-bg / --warn-b | #1d1810 / rgba(224,184,120,.18) | #faf3e7 / rgba(138,90,19,.16) |
| --bad-bg / --bad-b | #1f1213 / rgba(229,142,142,.18) | #fbeeee / rgba(176,65,65,.16) |
| --acc-bg / --acc-b | #16142a / rgba(145,132,217,.22) | #f0eefb / rgba(100,85,192,.18) |
| --hero-bg | #e6e6e9 | #16171b |
| --hero-t / --hero-t2 | #131418 / rgba(19,20,24,.62) | #ececef / rgba(236,236,239,.62) |
| --hero-pill / --hero-hatch | rgba(19,20,24,.08) / .16 | rgba(236,236,239,.10) / .14 |
| --bar-dim / --bar-on | rgba(236,236,239,.16) / #ececef | rgba(22,23,27,.14) / #16171b |
| --shadow | 0 24px 60px -24px rgba(0,0,0,.6) | 0 24px 60px -28px rgba(20,20,40,.25) |

Variante opcional de héroe "indigo": `--hero-bg:#221d44; --hero-t:#ecebfa; --hero-t2:rgba(236,235,250,.66); --hero-pill:rgba(236,235,250,.10); --hero-hatch:rgba(181,171,252,.22)`.

Radios: 9 (segmento), 12 (botones, tiles, inputs), 16 (filas, toast), 18 (stats modal), 22 (KPI), 24 (cards), 28 (héroes, modal), 30 (pills). Espaciado: gaps 4/6/8/10/12/14/16/18/20/24; padding de página 32/40/64. Tamaños de texto: 11.5, 12, 12.5, 13, 13.5, 14, 14.5, 15, 16, 17, 18, 20, 22, 24, 26, 34, 40, 44, 48, 52, clamp héroe.

Keyframes: `pulseDot` (opacidad 1↔.25, 2s), `rise` (opacity 0 + translateY 10px → none), `spin` (rotate 360°).

## Assets
- `assets/logo-n.png` — logo "N" del cliente (56×61, fondo blanco). Pedir versión SVG para producción.
- Iconos: **Phosphor Icons** (regular y fill) — https://phosphoricons.com (`@phosphor-icons/react`).
- Fuentes: Inter y JetBrains Mono (Google Fonts).
- Sistema de diseño base: Nocturne (`_ds/.../styles.css`) — solo como referencia de tokens; los tokens efectivos son los de la tabla.

## Files
- `FinOps Console v8.dc.html` — prototipo completo (plantilla + lógica + datos mock).
- `support.js` — runtime para abrir el prototipo en el navegador (no forma parte del producto).
- `assets/logo-n.png` — logo.
- `_ds/nocturne-…/` — hoja de estilos y bundle del sistema de diseño.
